<script setup>

</script>

<template>
<div class="h-[880px] bg-[#111111] flex items-center justify-center">
  <img class="w-[1300px] mx-auto max-h-[880px] object-cover" src="@/assets/img/icon14.png" alt="">
</div>
</template>

<style scoped lang="scss">

</style>