<script setup>

</script>

<template>
  <div class="mt-[204px]">
    <div class="title">
      onsistent Temp<br/>
      Ideal for Rosin
    </div>
    <div class="w-[1230px] mx-auto mt-[185px]">
      <div class="greenText">RTD Control</div>
      <div class="flex justify-between mt-[19px]">
        <div class="title2">
          Best flavor preservation
        </div>
        <div class="label">
          Powered by Unicore tech, UNIT PRO combines smoothness with purity, ensuring efficient THC and terpene extraction without burning, and guarantees an exceptional session every time.
        </div>
      </div>
      <div class="flex justify-between mt-[90px]">
        <img class="h-[500px] w-[480px] rounded-[20px]" src="@/assets/img/icon20.png" alt="">
        <img class="h-[500px] w-[730px] rounded-[20px]" src="@/assets/img/icon21.png" alt="">
      </div>
    </div>

    <div class="w-[1230px] mx-auto mt-[227px]">
      <div class="greenText">Built-in wires</div>
      <div class="flex justify-between mt-[19px]">
        <div class="title2">
          No dry burning
        </div>
        <div class="label">
          heating coil is embedded within the ceramic core, this way, the oil is heated by the ceramic core and not by exposed hot wires, maximizing prevention of burnt flavors and preservation.
        </div>
      </div>
      <div class="flex justify-between mt-[90px]">

        <img class="h-[500px] w-[730px] rounded-[20px]" src="@/assets/img/icon21.png" alt="">
        <img class="h-[500px] w-[480px] rounded-[20px]" src="@/assets/img/icon20.png" alt="">
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
.title{
  text-align: center;
  font-family: Roboto;
  font-size: 80px;
  font-style: normal;
  font-weight: 700;
  line-height: 80px; /* 100% */
  background: linear-gradient(180deg, #1CE785 0%, #A8FFD5 50%, #1CE785 100%);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.greenText{
  color: #1CE785;
  font-family: Roboto;
  font-size: 20px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
}
.title2{
  color: #FFF;
  font-family: Roboto;
  font-size: 40px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
}
.label{
  color: #FFF;
  font-family: Roboto;
  font-size: 20px;
  font-style: normal;
  font-weight: 400;
  line-height: 30px; /* 150% */
  width: 622.074px;
  flex-shrink: 0;
}
</style>