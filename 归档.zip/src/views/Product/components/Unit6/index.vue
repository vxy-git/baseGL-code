<script setup>

</script>

<template>
<div class="mt-[180px]">
  <div class="label">
    High-end feature
  </div>
  <div class="title mt-[20px]">
    Inhale & Button Activated
  </div>
  <div class="flex justify-center gap-x-[20px] mt-[54px]">
    <img class="w-[605px] h-[440px] rounded-[20px]" src="@/assets/img/icon23.png" alt="">
    <img class="w-[605px] h-[440px] rounded-[20px]" src="@/assets/img/icon23.png" alt="">
  </div>
</div>
</template>

<style scoped lang="scss">
.label{
  color: #1CE785;
  font-family: Roboto;
  font-size: 20px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
  text-align: center;
}
.title{
  color: #FFF;
  font-family: Roboto;
  font-size: 40px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
  text-align: center;
}
</style>