<script setup>

</script>

<template>
<div class="pt-[133px]">
  <div>
    <div class="title">
      UNICORE<br/>
      POWERED
    </div>
    <img src="@/assets/img/icon15.png" class="w-[1460px] mx-auto -mt-[53px]" alt="">
  </div>



  <div>
    <div class="mt-[130.75px] relative">
      <div class="absolute top-0 left-0 w-full">
        <div class="smallTitle">
          Award-Winning
        </div>
        <div class="wTitle">
          Simply the best
        </div>
        <div class="text !mt-[34px]">
          In June 2025, UNIT secured 1st place in the Live Resin vape category at the 2025 California State Fair Cannabis Awards. This victory is a testament to our product's excellence. With this market validation, we are not just confident, but eager to bring this golden standard to more brands using Resin and Rosin.
        </div>
      </div>
      <img src="@/assets/img/icon16.png" class="w-[1460px] mx-auto" alt="">
    </div>
  </div>


  <div>
    <div class="mt-[204px] relative">
      <div class=" top-0 left-0 w-full">
        <div class="smallTitle">
          A Significant Breakthrough
        </div>
        <div class="wTitle">
          U-shape design<br/>
          Pioneering industry
        </div>
        <div class="text !mt-[34px]">
          Our patented U-shape ceramic design is the result of extensive testing and validation of various structures. It is the optimal structure for the vast majority of Resin and Rosin oils on the market.
        </div>
      </div>
      <img src="@/assets/img/icon17.png" class="w-[1460px] mx-auto -mt-[50px]" alt="">
    </div>
  </div>


  <div>
    <div class="mt-[204px] relative">
      <div class=" top-0 left-0 w-full">
        <div class="smallTitle">
          100% Rosin-Ready
        </div>
        <div class="wTitle">
          Savor the most natural<br/>
          and rich flavors
        </div>
        <div class="text !mt-[34px]">
          Our patented U-shape ceramic design is 30% thinner than ordinary ceramics, which means fewer terpene molecules are filtered out and the rich, natural flavors are preserved.
        </div>
        <div class="flex justify-center gap-x-[150px] mt-[78px]">
          <div class="flex flex-col items-center justify-center ">
            <div class="text1 h-[40px]">
              30%
            </div>
            <div class="text2">
              Thinner in Structure
            </div>
          </div>
          <div class="flex flex-col items-center h-[40px]">
            <div class="text1 flex">
              45%
              <img class="size-[40px]" src="@/assets/img/icon19.png" alt="">
            </div>
            <div class="text2">
              Flavor Retention
            </div>
          </div>
        </div>
      </div>
      <img src="@/assets/img/icon18.png" class="w-[1460px] mx-auto mt-[82px]" alt="">
    </div>
  </div>
</div>
</template>

<style scoped lang="scss">
.title{
  text-align: center;
  font-family: Roboto;
  font-size: 80px;
  font-style: normal;
  font-weight: 700;
  line-height: 80px; /* 100% */
  background: linear-gradient(180deg, #1CE785 0%, #A8FFD5 50%, #1CE785 100%);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.smallTitle{
  color: #1CE785;
  font-family: Roboto;
  font-size: 20px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
  text-align: center;
}
.wTitle{
  color: #FFF;
  font-family: Roboto;
  font-size: 40px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
  text-align: center;
  margin-top: 20px;
}
.text{
  width: 1200px;
  margin: 0 auto;
  color: #FFF;
  text-align: center;
  font-family: Roboto;
  font-size: 20px;
  font-style: normal;
  font-weight: 400;
  line-height: 30px; /* 150% */
}
.text1{
  color: #1CE785;
  font-family: Roboto;
  font-size: 40px;
  font-style: normal;
  font-weight: 700;
  line-height: 30px; /* 75% */
}
.text2{
  color: #FFF;
  font-family: Roboto;
  font-size: 20px;
  font-style: normal;
  font-weight: 400;
  line-height: 30px; /* 150% */
  margin-top: 5px;
}
</style>