<script setup>

</script>

<template>
<div class="pb-[208px]">
  <div class="title -mt-[8px]">
    Twice the performance,<br/>
    Triple the flavors.
  </div>
  <div class="label mt-[34px]">
    Get ready for DUKES to spice up your taste buds. It combines both flavors for a new experience, allowing users to switch between<br/> tastes or enjoy a mix of both.
  </div>
  <img class="w-[1020px] mx-auto mt-[47px] h-[580px] block" src="@/assets/img/icon33.png" alt="">
</div>
</template>

<style scoped lang="scss">
.title{
  color: #111;
  text-align: center;
  font-family: Roboto;
  font-size: 40px;
  font-style: normal;
  font-weight: 700;
  line-height: 47px;
}
.label{
  color: #444;
  text-align: center;
  font-family: Roboto;
  font-size: 20px;
  font-style: normal;
  font-weight: 400;
  line-height: 30px; /* 150% */
}
</style>