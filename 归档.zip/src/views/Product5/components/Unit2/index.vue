<script setup>

</script>

<template>
<div class="flex flex-col gap-y-[20px] pt-[110px]">
  <div class="flex justify-center gap-x-[20px]">
    <div class="w-[605px] h-[340px] relative">
      <div class="text absolute top-[21px] left-[28px]">Dual Chamber</div>
      <img class="size-full rounded-[20px] object-cover" src="@/assets/img/icon31.png" alt="">
    </div>
    <div class="w-[605px] h-[340px] relative">
      <div class="text absolute top-[21px] left-[28px]">Post-Free</div>
      <img class="size-full rounded-[20px] object-cover" src="@/assets/img/icon31.png" alt="">
    </div>
  </div>
  <div class="flex justify-center gap-x-[20px]">
    <div class="w-[605px] h-[340px] relative">
      <div class="text absolute top-[21px] left-[28px]">Multiple Options</div>
      <img class="size-full rounded-[20px] object-cover" src="@/assets/img/icon31.png" alt="">
    </div>
    <div class="w-[605px] h-[340px] relative">
      <div class="text absolute top-[21px] left-[28px]">Advanced Interactivity</div>
      <img class="size-full rounded-[20px] object-cover" src="@/assets/img/icon31.png" alt="">
    </div>
  </div>
</div>
</template>

<style scoped lang="scss">
.text{
  color: #FFF;
  text-align: center;
  font-family: Roboto;
  font-size: 24px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
}
</style>