<script setup>

</script>

<template>
  <div class="bg-black pt-[236px]">
    <div class="title">
      Post-Free Design
    </div>
    <div class="w-[1227px] mx-auto mt-[142px] flex justify-between">
      <div class="pt-[7px]">
        <div class="gtext">
          Terpene-Boosted
        </div>
        <div class="title1">
          Get the smoothest and cleanest hit.
        </div>
        <div class="label">
          The Gemco core in dual chamber can release the purest, richest, and most authentic terpene flavors when used individually. When both chambers are engaged, it creates the most perfect flavor collision, allowing the dual aromas to swirl on your taste buds.
        </div>
        <img src="@/assets/img/icon35.png" class="w-[600px] h-[360px] mt-[55px] rounded-[20px]" alt="">
      </div>
      <img class="w-[500px] h-[650px] rounded-[20px]" src="@/assets/img/icon36.png" alt="">
    </div>
<!--    <img class="w-[900px] h-[409px] mx-auto mt-[64px]" src="@/assets/img/icon34.png" alt="">-->
  </div>
</template>

<style scoped lang="scss">
.title{
  text-align: center;
  font-family: Roboto;
  font-size: 80px;
  font-style: normal;
  font-weight: 700;
  line-height: 94px;
  background: linear-gradient(90deg, #1CE785 0%, #10814A 100%);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.gtext{
  color: #1CE785;
  font-family: Roboto;
  font-size: 20px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
}
.title1{
  color: #FFF;
  font-family: Roboto;
  font-size: 40px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
  margin-top: 18px;
}
.label{
  width: 594px;
  height: 120px;
  flex-shrink: 0;
  color: #FFF;
  font-family: Roboto;
  font-size: 20px;
  font-style: normal;
  font-weight: 400;
  line-height: 30px; /* 150% */
  @apply mt-[18px];
}
</style>