<script setup>

</script>

<template>
  <div class=" bg-black pt-[392px] pb-[215px]">
    <div class="w-[calc(520px+15px+695px)] mx-auto">
      <div class="justify-between flex">
        <div class="bg-[#D9D9D9] h-[440px] w-[520px] rounded-[20px] relative">
          <div class="tag absolute left-[21px] top-[25px]">
            Dosing Timer
          </div>
          <img src="" alt="">
        </div>
        <div class="bg-[#D9D9D9] h-[440px] w-[695px] rounded-[20px] relative">
          <div class="tag absolute left-[21px] top-[25px]">
            Preheat Status Indication
          </div>
          <img src="" alt="">
        </div>
      </div>
      <div class="justify-between flex mt-[15px]">
        <div class="bg-[#D9D9D9] h-[440px] w-[695px] rounded-[20px] relative">
          <div class="tag absolute left-[21px] top-[25px]">
            3-Temperature Control
          </div>
          <img src="" alt="">
        </div>
        <div class="bg-[#D9D9D9] h-[440px] w-[520px] rounded-[20px] relative">
          <div class="tag absolute left-[21px] top-[25px]">
            Battery Life Monitor
          </div>
          <img src="" alt="">
        </div>

      </div>
    </div>
  </div>

</template>

<style scoped lang="scss">
.tag{
  padding: 0 30px;
  height: 40px;
  flex-shrink: 0;
  border-radius: 50px;
  background: #FFF;
  color: #000;
  font-family: Roboto;
  font-size: 18px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>