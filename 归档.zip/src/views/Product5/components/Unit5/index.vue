<script setup>

</script>

<template>
<div class="bg-black pt-[294px]">
<div class="title">
  Dual Gemco Core
</div>
  <img class="w-[900px] h-[409px] mx-auto mt-[64px]" src="@/assets/img/icon34.png" alt="">
</div>
</template>

<style scoped lang="scss">
.title{
  text-align: center;
  font-family: Roboto;
  font-size: 80px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
  background: linear-gradient(90deg, #10814A 0%, #1CE785 50%);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
</style>