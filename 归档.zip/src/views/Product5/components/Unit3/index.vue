<script setup>

</script>

<template>
  <div class="pt-[calc(325px)] pb-[calc(325px)] flex justify-center">
    <div class="h-[234px] flex items-center">
      <img class="h-[148px]" src="@/assets/img/icon32.png" alt="">
    </div>
  </div>
</template>

<style scoped lang="scss">

</style>