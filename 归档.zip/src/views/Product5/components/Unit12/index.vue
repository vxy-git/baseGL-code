<script setup>

</script>

<template>
<div class="h-[880px] flex justify-center items-center bg-[#F8F9FD]">
  <div class="title">
    GO
    <img class="size-[261px]" src="@/assets/img/icon41.png" alt="">
    Creative
  </div>
</div>
</template>

<style scoped lang="scss">
.title{
  color: #111;
  text-align: center;
  font-family: Roboto;
  font-size: 150px;
  font-style: normal;
  font-weight: 700;
  line-height: 261px; /* 53.333% */
  display: flex;
  justify-content: center;
  gap: 32px;
}
</style>