<script setup>

</script>

<template>
    <div class="pt-[387px] bg-black">
      <div class="w-[999px] mx-auto  flex relative justify-center">
        <img src="@/assets/img/icon38.png"  class="absolute left-0 size-[34px] -top-[4px] animate-pulse" alt="">
        <img src="@/assets/img/icon38.png"  class="absolute left-[35px] size-[22px] -top-[22px] animate-pulse" alt="">
        <div class="title text-nowrap">Tap into a whole new level<br/>of interaction</div>
      </div>
    </div>
</template>

<style scoped lang="scss">
.title{
  text-align: center;
  font-family: Roboto;
  font-size: 80px;
  font-style: italic;
  font-weight: 800;
  line-height: 80px; /* 100% */
  background: linear-gradient(89deg, #FB7D4E 2.34%, #E25667 49.42%, #6A87D7 96.5%);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  letter-spacing: -.4px;
}
</style>