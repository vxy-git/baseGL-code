<script setup>

</script>

<template>
<div class="h-[880px] bg-[#111111] flex items-center justify-center">
</div>
</template>

<style scoped lang="scss">

</style>