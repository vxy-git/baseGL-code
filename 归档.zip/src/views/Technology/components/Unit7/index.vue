<script setup>
import icon6_1 from '@/assets/img/icon6_1.png'
</script>

<template>
<div class=" ">

    
    <div class="w-[1300px] h-[560px] relative mx-auto mt-[260px]">
      <img :src="icon6_1" alt="" class="w-[1300px] h-[560px]" />
        <div class="absolute size-full top-0 left-0 flex flex-col items-center pt-[142px]">
          <div class="title2">
            From lab to awards: journey to the top
          </div>
          <div class="title3 mt-[54px]">
            Our R&D Director, Frank, with 20 years of industry experience, has worked with US labs for 18 months, conducting round-the-clock tests to redefine the gold standard for Rosin and Resin oils. This dedication means we don't just offer testing capabilities—we offer proven results.<br/>
            We once partnered with a client for a year-long testing phase to ensure their product not only made a big hit in the market but also stood the test of time.<br/>
            Choose us, and you're not just choosing a supplier—you're choosing a reliable partner you can always count on.
          </div>
        </div>
      
      
    </div>
    
</div>
</template>

<style scoped lang="scss">
.content-wrapper {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20px;
}


.title2 {
  width: 679px;
  height: 47px;
  color: #fff;
  font-family: 'Roboto', sans-serif;
  font-size: 40px;
  text-align: center;
  line-height: 1.1; // 缩短行间距
}

.title3 {
  width: 983px;
  color: #FFF;
  font-family: Roboto;
  font-size: 20px;
  font-style: normal;
  font-weight: 400;
  line-height: 30px; /* 150% */
}
</style>