<template>
    <div :class="$style.v10">
        <img :class="$style.icon" alt="" />
        <b :class="$style.unicore">UNICORE</b>
        <div :class="$style.contact">Contact</div>
        <img :class="$style.v10Icon" alt="" />
        <div :class="$style.new">New</div>
        <div :class="$style.ml1ml">0.5mL/1mL</div>
        <div :class="$style.v10Child" />
        <div :class="$style.ml2ml">1mL/2mL</div>
        <div :class="$style.productsTechnologyCustomizeParent">
            <div :class="$style.productsTechnologyCustomize">Products Technology Customize US Local Service Why Caleaf
            </div>
            <img :class="$style.cc097Web1Icon" alt="" />
            <div :class="$style.groupChild" />
            <div :class="$style.v10Contact">Contact</div>
            <img :class="$style.icon2" alt="" />
        </div>
        <img :class="$style.f8ce87521702273c1409a3f21a025bIcon" alt="" />
        <img :class="$style.v10Item" alt="" />
        <b :class="$style.watchVideo">Watch Video</b>
        <img :class="$style.playOneIcon" alt="" />
        <div :class="$style.v10Inner" />
        <div :class="$style.rectangleDiv" />
        <b :class="$style.savorTheMost">Savor the most natural <br />and rich flavors</b>
        <div :class="$style.weAlwaysStrive">We always strive to be pioneers in the industry.<br />Our patented U-shape
            ceramic design is the result of extensive testing and validation of various structures. It is the optimal
            structure for the vast majority of Resin and Rosin oils on the market.<br />It is 30% thinner than ordinary
            ceramics while maintaining the strength, which means fewer terpene molecules are filtered out, and the rich,
            natural flavors are preserved.</div>
        <b :class="$style.b">30%</b>
        <div :class="$style.thinnerInStructure">Thinner in Structure</div>
        <b :class="$style.v10B">45%</b>
        <img :class="$style.icon3" alt="" />
        <img :class="$style.icon4" alt="" />
        <div :class="$style.flavorRetention">Flavor Retention</div>
        <div :class="$style.rosinReady">100% Rosin-Ready</div>
        <b :class="$style.theMostEffective">The most effective<br />anti-clogging solution ever built.</b>
        <div :class="$style.mostCustomersHave">Most customers have reported bubble issues to us with various devices
            from different suppliers during oil filling. Our U-shape ceramic design solves this problem perfectly. No
            more burnt taste caused by clogged bubbles.</div>
        <div :class="$style.weFixedIt">We fixed it first</div>
        <img :class="$style.icon5" alt="" />
        <img :class="$style.cb667ea0894748b7b76baa18bf338Icon" alt="" />
        <div :class="$style.v10New">New</div>
        <div :class="$style.lineDiv" />
        <b :class="$style.noMoreDry">No more dry burning</b>
        <div :class="$style.wePayAttention">We pay attention to every detail.<br />It is only when we use the
            highest-grade nichrome alloy as the heating coil material, shape it for uniform heat distribution, and embed
            it into the ceramic core, allowing the oil to be heated by the ceramic and not by exposed hot wires, that we
            say, "That's it. This is a truly perfect structure!"</div>
        <div :class="$style.builtInWires">Built-in wires</div>
        <b :class="$style.aerospaceGradeHighThermal">Aerospace-grade<br />high thermal conductivity.</b>
        <img :class="$style.image2Icon" alt="" />
        <div :class="$style.weNeverLet">We never let existing rules and regulations hold us back.<br />We pioneered the
            incorporation of aerospace-grade high thermal conductivity materials into ceramics. Through round-the-clock
            firing and suction tests, we have finally succeeded in firing the ceramic at 1832 °F (1000 ℃), surpassing
            our peers by 20%.</div>
        <div :class="$style.atFiringTemp">20% at firing temp</div>
        <img :class="$style.cab5bca749f1c2a08c6b96b70ec1dbIcon" alt="" />
        <div :class="$style.v10V10Child" />
        <b :class="$style.consistentTemp">Consistent Temp</b>
        <b :class="$style.ourClientsHave">Our clients have taken home trophies</b>
        <div :class="$style.weTakePride">We take pride in having earned our clients’ trust. The trophies shine brightly
            and stand as proof of our products’ excellence.</div>
        <div :class="$style.v10Child2" />
        <b :class="$style.v10OurClientsHave">Our clients have taken home trophies</b>
        <div :class="$style.v10WeTakePride">We take pride in having earned our clients’ trust. The trophies shine
            brightly and stand as proof of our products’ excellence.</div>
        <div :class="$style.v10Child3" />
        <div :class="$style.unicoreCombinesSmoothness">Unicore combines smoothness with purity, ensuring efficient THC
            and terpene extraction without burning, and guarantees an exceptional session every time.</div>
        <div :class="$style.rtdControl">RTD Control</div>
        <div :class="$style.v10Child4" />
        <img :class="$style.rectangleIcon" alt="" />
        <b :class="$style.fromLabTo">From lab to awards: journey to the top</b>
        <div :class="$style.ourRdDirector">Our R&D Director, Frank, with 20 years of industry experience, has worked
            with US labs for 18 months, conducting round-the-clock tests to redefine the gold standard for Rosin and
            Resin oils. This dedication means we don't just offer testing capabilities—we offer proven results.<br />We
            once partnered with a client for a year-long testing phase to ensure their product not only made a big hit
            in the market but also stood the test of time.<br />Choose us, and you're not just choosing a
            supplier—you're choosing a reliable partner you can always count on.</div>
        <i :class="$style.unicoreProducts">UNICORE Products</i>
        <div :class="$style.rectangleParent">
            <div :class="$style.groupItem" />
            <div :class="$style.unitUnicoreTechContainer">
                <b>UNIT<br /></b>
                <span :class="$style.unicoreTech">UNICORE™ tech & large display</span>
            </div>
            <img :class="$style.icon6" alt="" />
            <div :class="$style.groupInner" />
            <div :class="$style.viewMore">View More</div>
        </div>
        <div :class="$style.rectangleGroup">
            <div :class="$style.groupItem" />
            <div :class="$style.unitUnicoreTechContainer">
                <b>UNIT<br /></b>
                <span :class="$style.unicoreTech">UNICORE™ tech & large display</span>
            </div>
            <img :class="$style.icon6" alt="" />
            <div :class="$style.groupInner" />
            <div :class="$style.viewMore">View More</div>
        </div>
        <div :class="$style.rectangleContainer">
            <div :class="$style.groupItem" />
            <div :class="$style.unitUnicoreTechContainer">
                <b>UNIT<br /></b>
                <span :class="$style.unicoreTech">UNICORE™ tech & large display</span>
            </div>
            <img :class="$style.icon6" alt="" />
            <div :class="$style.groupInner" />
            <div :class="$style.viewMore">View More</div>
        </div>
        <div :class="$style.groupDiv">
            <div :class="$style.groupItem" />
            <div :class="$style.unitUnicoreTechContainer">
                <b>UNIT<br /></b>
                <span :class="$style.unicoreTech">UNICORE™ tech & large display</span>
            </div>
            <img :class="$style.icon6" alt="" />
            <div :class="$style.groupInner" />
            <div :class="$style.viewMore">View More</div>
        </div>
        <div :class="$style.ellipseDiv" />
        <img :class="$style.rightSmallIcon" alt="" />
        <div :class="$style.v10Child5" />
        <img :class="$style.v10RightSmallIcon" alt="" />
        <div :class="$style.v10Child6" />
        <div :class="$style.productsParent">
            <b :class="$style.products">Products</b>
            <div :class="$style.forResinrosinPod">For Resin/Rosin<br />Pod System<br />Full Ceramic<br />D9
                Distillate<br />US STOCK<br />Dab Pen<br />510 Cartridge<br />D8 Distillate</div>
            <b :class="$style.technology">Technology</b>
            <div :class="$style.productSupportRepair">Product Support<br />Repair Service<br />After-Sales
                Policy<br />Care Service<br />Downloads</div>
            <b :class="$style.customize">Customize</b>
            <div :class="$style.v10ForResinrosinPod">For Resin/Rosin<br />Pod System<br />Full Ceramic<br />D9
                Distillate<br />US STOCK<br />Dab Pen<br />510 Cartridge<br />D8 Distillate</div>
            <b :class="$style.whyCaleaf">Why Caleaf</b>
            <div :class="$style.aboutCaleafPress">About Caleaf<br />Press<br />Blog<br />CSR<br />Awards<br />Join Us
            </div>
            <b :class="$style.subscribe">Subscribe</b>
            <div :class="$style.getTheLatest">Get the latest news from CALEAF TECH</div>
            <div :class="$style.iAgreeWithContainer">
                <span>I agree with the </span>
                <span :class="$style.privacyPolicy">Privacy Policy </span>
                <span>and l'dlike to receive the latest CALEAF TECH newsand deals by email.</span>
            </div>
            <div :class="$style.groupChild7" />
            <div :class="$style.groupChild8" />
            <div :class="$style.signUp">Sign Up</div>
            <div :class="$style.email">Email</div>
            <div :class="$style.groupChild9" />
            <div :class="$style.groupChild10" />
            <img :class="$style.youtube1Icon" alt="" />
            <img :class="$style.linkedin1Icon" alt="" />
            <img :class="$style.facebook1Icon" alt="" />
            <img :class="$style.ins1Icon" alt="" />
            <img :class="$style.tiktok1Icon" alt="" />
            <div :class="$style.copyright2025">Copyright © 2025 CALEAF TECH All rights reserved.</div>
            <div :class="$style.designedByHoly">Designed by HOLY</div>
        </div>
    </div>
</template>
<style
    module>
    .v10 {
        width: 100%;
        height: 9467px;
        position: relative;
        background-color: #000;
        overflow: hidden;
        text-align: left;
        font-size: 20px;
        color: #fff;
        font-family: Roboto;
    }

    .icon {
        position: absolute;
        top: 3024px;
        left: calc(50% - 960px);
        width: 1920px;
        height: 1080px;
        object-fit: cover;
        opacity: 0.56;
    }

    .unicore {
        position: absolute;
        top: 373px;
        left: calc(50% - 421px);
        font-size: 200px;
    }

    .contact {
        position: absolute;
        top: 38.5px;
        left: 1525.5px;
        font-size: 18px;
        color: #222;
        display: none;
    }

    .v10Icon {
        position: absolute;
        top: 39px;
        left: 1660px;
        width: 22px;
        height: 22px;
        display: none;
    }

    .new {
        position: absolute;
        top: 1383.77px;
        left: 1960px;
        font-family: Arial;
        color: #1ce785;
        text-align: center;
    }

    .ml1ml {
        position: absolute;
        top: 1868.5px;
        left: 2113px;
        font-size: 18px;
        font-family: Arial;
        color: #000;
    }

    .v10Child {
        position: absolute;
        top: 1917px;
        left: 2052.75px;
        border-radius: 50px;
        background-color: #1ce785;
        width: 130px;
        height: 40px;
    }

    .ml2ml {
        position: absolute;
        top: 1925.5px;
        left: 2080.75px;
        font-size: 18px;
        font-family: Arial;
        color: #000;
    }

    .productsTechnologyCustomizeParent {
        position: absolute;
        top: 30px;
        left: 310px;
        width: 1300px;
        height: 40px;
        font-size: 16px;
    }

    .productsTechnologyCustomize {
        position: absolute;
        top: 8.5px;
        left: 246px;
        white-space: pre-wrap;
    }

    .cc097Web1Icon {
        position: absolute;
        top: 5px;
        left: 0px;
        width: 187.2px;
        height: 30px;
        object-fit: cover;
    }

    .groupChild {
        position: absolute;
        top: 0px;
        left: 1106px;
        border-radius: 50px;
        background-color: #1ce785;
        width: 140px;
        height: 40px;
    }

    .v10Contact {
        position: absolute;
        top: 10px;
        left: 1145px;
        font-size: 18px;
        color: #222;
    }

    .icon2 {
        position: absolute;
        top: 9px;
        left: 1278px;
        width: 22px;
        height: 22px;
    }

    .f8ce87521702273c1409a3f21a025bIcon {
        position: absolute;
        top: 174px;
        left: 738px;
        width: 445px;
        height: 633px;
        object-fit: cover;
    }

    .v10Item {
        position: absolute;
        top: 652px;
        left: 1275px;
        border-radius: 50px;
        width: 300px;
        height: 60px;
        object-fit: cover;
        opacity: 0.7;
    }

    .watchVideo {
        position: absolute;
        top: 671px;
        left: 1352px;
    }

    .playOneIcon {
        position: absolute;
        top: 670px;
        left: 1474px;
        width: 24px;
        height: 24px;
    }

    .v10Inner {
        position: absolute;
        top: 979.5px;
        left: 749.5px;
        border-right: 1px solid #fff;
        box-sizing: border-box;
        width: 1px;
        height: 2045px;
        opacity: 0.2;
    }

    .rectangleDiv {
        position: absolute;
        top: 1130px;
        left: 180px;
        border-radius: 20px;
        background-color: #d9d9d9;
        width: 400px;
        height: 680px;
    }

    .savorTheMost {
        position: absolute;
        top: 1172.55px;
        left: calc(50% + 62px);
        font-size: 40px;
        text-align: center;
    }

    .weAlwaysStrive {
        position: absolute;
        top: 1295px;
        left: calc(50% - 104px);
        line-height: 30px;
        text-align: center;
        display: inline-block;
        width: 750px;
        height: 232px;
    }

    .b {
        position: absolute;
        top: 1563px;
        left: 1044px;
        font-size: 40px;
        line-height: 30px;
        color: #1ce785;
    }

    .thinnerInStructure {
        position: absolute;
        top: 1603.72px;
        left: 996px;
        line-height: 30px;
    }

    .v10B {
        position: absolute;
        top: 1563px;
        left: 1339.5px;
        font-size: 40px;
        line-height: 30px;
        color: #1ce785;
    }

    .icon3 {
        position: absolute;
        top: 1563px;
        left: 1412.93px;
        width: 43.1px;
        height: 39.8px;
        object-fit: cover;
    }

    .icon4 {
        position: absolute;
        top: 3474px;
        left: 296px;
        width: 28px;
        height: 26px;
        object-fit: cover;
    }

    .flavorRetention {
        position: absolute;
        top: 1603.72px;
        left: 1320.5px;
        line-height: 30px;
    }

    .rosinReady {
        position: absolute;
        top: 1130px;
        left: calc(50% + 189px);
        color: #1ce785;
        text-shadow: 1px 0 0 #000, 0 1px 0 #000, -1px 0 0 #000, 0 -1px 0 #000;
    }

    .theMostEffective {
        position: absolute;
        top: 2252.55px;
        left: calc(50% - 21px);
        font-size: 40px;
        text-align: center;
    }

    .mostCustomersHave {
        position: absolute;
        top: 2391px;
        left: calc(50% - 104px);
        line-height: 30px;
        text-align: center;
        display: inline-block;
        width: 750px;
        height: 232px;
    }

    .weFixedIt {
        position: absolute;
        top: 2210px;
        left: calc(50% + 205px);
        color: #1ce785;
    }

    .icon5 {
        position: absolute;
        top: 1684px;
        left: 848px;
        width: 763px;
        height: 368px;
        object-fit: cover;
    }

    .cb667ea0894748b7b76baa18bf338Icon {
        position: absolute;
        top: 2547px;
        left: 934px;
        width: 595px;
        height: 412px;
        object-fit: cover;
    }

    .v10New {
        position: absolute;
        top: 4662.77px;
        left: 1960px;
        font-family: Arial;
        color: #1ce785;
        text-align: center;
    }

    .lineDiv {
        position: absolute;
        top: 4258.5px;
        left: 1169.5px;
        border-right: 1px solid #fff;
        box-sizing: border-box;
        width: 1px;
        height: 1631px;
        opacity: 0.2;
    }

    .noMoreDry {
        position: absolute;
        top: 4451.55px;
        left: calc(50% - 460px);
        font-size: 40px;
        text-align: center;
    }

    .wePayAttention {
        position: absolute;
        top: 4521px;
        left: calc(50% - 650px);
        line-height: 30px;
        text-align: center;
        display: inline-block;
        width: 750px;
        height: 232px;
    }

    .builtInWires {
        position: absolute;
        top: 4409px;
        left: calc(50% - 332px);
        color: #1ce785;
    }

    .aerospaceGradeHighThermal {
        position: absolute;
        top: 3516.55px;
        left: calc(50% - 650px);
        font-size: 40px;
    }

    .image2Icon {
        position: absolute;
        top: 3484px;
        left: 970px;
        width: 640px;
        height: 341px;
        object-fit: cover;
    }

    .weNeverLet {
        position: absolute;
        top: 3641px;
        left: calc(50% - 650px);
        line-height: 30px;
        display: inline-block;
        width: 600px;
        height: 232px;
    }

    .atFiringTemp {
        position: absolute;
        top: 3474px;
        left: calc(50% - 625px);
        color: #1ce785;
    }

    .cab5bca749f1c2a08c6b96b70ec1dbIcon {
        position: absolute;
        top: 4353px;
        left: 1234px;
        width: 577px;
        height: 560px;
        object-fit: cover;
    }

    .v10V10Child {
        position: absolute;
        top: 4720px;
        left: 310px;
        border-radius: 20px;
        background-color: #d9d9d9;
        width: 750px;
        height: 400px;
    }

    .consistentTemp {
        position: absolute;
        top: 5298.55px;
        left: calc(50% - 427px);
        font-size: 40px;
        text-align: center;
    }

    .ourClientsHave {
        position: absolute;
        top: 6163px;
        left: calc(50% - 400px);
        font-size: 40px;
    }

    .weTakePride {
        position: absolute;
        top: 6297px;
        left: calc(50% - 400px);
        line-height: 30px;
        display: inline-block;
        width: 800px;
        height: 100px;
    }

    .v10Child2 {
        position: absolute;
        top: 6251px;
        left: calc(50% - 960px);
        background-color: #1ce785;
        width: 1920px;
        height: 2px;
    }

    .v10OurClientsHave {
        position: absolute;
        top: 6671px;
        left: calc(50% - 400px);
        font-size: 40px;
    }

    .v10WeTakePride {
        position: absolute;
        top: 7193px;
        left: calc(50% - 400px);
        line-height: 30px;
        display: inline-block;
        width: 800px;
        height: 100px;
    }

    .v10Child3 {
        position: absolute;
        top: 6759px;
        left: calc(50% - 400px);
        border-radius: 20px;
        background-color: #d9d9d9;
        width: 800px;
        height: 400px;
    }

    .unicoreCombinesSmoothness {
        position: absolute;
        top: 5368px;
        left: calc(50% - 650px);
        line-height: 30px;
        text-align: center;
        display: inline-block;
        width: 750px;
        height: 85px;
    }

    .rtdControl {
        position: absolute;
        top: 5256px;
        left: calc(50% - 328px);
        color: #1ce785;
    }

    .v10Child4 {
        position: absolute;
        top: 5489px;
        left: 310px;
        border-radius: 20px;
        background-color: #d9d9d9;
        width: 750px;
        height: 400px;
    }

    .rectangleIcon {
        position: absolute;
        top: 7518px;
        left: calc(50% - 650px);
        border-radius: 20px;
        width: 1300px;
        height: 560px;
        object-fit: cover;
        opacity: 0.6;
    }

    .fromLabTo {
        position: absolute;
        top: 7660px;
        left: calc(50% - 339px);
        font-size: 40px;
    }

    .ourRdDirector {
        position: absolute;
        top: 7761px;
        left: calc(50% - 491px);
        line-height: 30px;
        display: inline-block;
        width: 983px;
        height: 217px;
    }

    .unicoreProducts {
        position: absolute;
        top: 8254px;
        left: calc(50% - 650px);
        font-size: 80px;
        line-height: 80px;
        font-weight: 800;
        color: #1ce785;
        text-align: center;
    }

    .rectangleParent {
        position: absolute;
        top: 8379px;
        left: 309px;
        width: 305px;
        height: 440px;
        font-size: 24px;
    }

    .groupItem {
        position: absolute;
        top: 0px;
        left: 0px;
        border-radius: 20px;
        background-color: #23242a;
        width: 305px;
        height: 440px;
    }

    .unitUnicoreTechContainer {
        position: absolute;
        top: 274px;
        left: 20px;
        line-height: 32px;
    }

    .unicoreTech {
        font-size: 16px;
        color: #f5f5f5;
    }

    .icon6 {
        position: absolute;
        top: 63px;
        left: 60px;
        width: 185px;
        height: 165px;
        object-fit: cover;
    }

    .groupInner {
        position: absolute;
        top: 358px;
        left: 20px;
        border-radius: 50px;
        background-color: #1ce785;
        width: 130px;
        height: 40px;
    }

    .viewMore {
        position: absolute;
        top: 369px;
        left: 47px;
        font-size: 16px;
        color: #000;
    }

    .rectangleGroup {
        position: absolute;
        top: 8379px;
        left: 641px;
        width: 305px;
        height: 440px;
        font-size: 24px;
    }

    .rectangleContainer {
        position: absolute;
        top: 8379px;
        left: 973px;
        width: 305px;
        height: 440px;
        font-size: 24px;
    }

    .groupDiv {
        position: absolute;
        top: 8379px;
        left: 1305px;
        width: 305px;
        height: 440px;
        font-size: 24px;
    }

    .ellipseDiv {
        position: absolute;
        top: 8574px;
        left: 1549px;
        border-radius: 50%;
        background-color: #1ce785;
        width: 50px;
        height: 50px;
    }

    .rightSmallIcon {
        position: absolute;
        top: 8587px;
        left: 1562px;
        width: 24px;
        height: 24px;
    }

    .v10Child5 {
        position: absolute;
        top: 8574px;
        left: 319px;
        border-radius: 50%;
        background-color: #fff;
        width: 50px;
        height: 50px;
    }

    .v10RightSmallIcon {
        position: absolute;
        top: 8587px;
        left: 332px;
        width: 24px;
        height: 24px;
        object-fit: contain;
        opacity: 0.4;
    }

    .v10Child6 {
        position: absolute;
        top: 8946px;
        left: calc(50% - 960px);
        background-color: #fff;
        width: 1920px;
        height: 521px;
    }

    .productsParent {
        position: absolute;
        top: 9036px;
        left: 310px;
        width: 1301px;
        height: 395px;
        font-size: 16px;
        color: #555;
    }

    .products {
        position: absolute;
        top: 0px;
        left: 0px;
        font-size: 18px;
        display: inline-block;
        color: #000;
        width: 131px;
    }

    .forResinrosinPod {
        position: absolute;
        top: 32px;
        left: 0px;
        line-height: 32px;
        display: inline-block;
        width: 131px;
    }

    .technology {
        position: absolute;
        top: 0px;
        left: 237px;
        font-size: 18px;
        display: inline-block;
        color: #000;
        width: 131px;
    }

    .productSupportRepair {
        position: absolute;
        top: 32px;
        left: 237px;
        line-height: 32px;
        display: inline-block;
        width: 153px;
    }

    .customize {
        position: absolute;
        top: 0px;
        left: 496px;
        font-size: 18px;
        display: inline-block;
        color: #000;
        width: 131px;
    }

    .v10ForResinrosinPod {
        position: absolute;
        top: 32px;
        left: 496px;
        line-height: 32px;
        display: inline-block;
        width: 113px;
    }

    .whyCaleaf {
        position: absolute;
        top: 0px;
        left: 716px;
        font-size: 18px;
        display: inline-block;
        color: #000;
        width: 131px;
    }

    .aboutCaleafPress {
        position: absolute;
        top: 32px;
        left: 715px;
        line-height: 32px;
        display: inline-block;
        width: 102px;
    }

    .subscribe {
        position: absolute;
        top: 0px;
        left: 1003px;
        font-size: 18px;
        display: inline-block;
        color: #000;
        width: 131px;
    }

    .getTheLatest {
        position: absolute;
        top: 32px;
        left: 1003px;
        line-height: 32px;
        display: inline-block;
        width: 297px;
    }

    .iAgreeWithContainer {
        position: absolute;
        top: 142px;
        left: 1032px;
        font-size: 14px;
        line-height: 22px;
        display: inline-block;
        width: 268px;
    }

    .privacyPolicy {
        color: #000;
    }

    .groupChild7 {
        position: absolute;
        top: 81px;
        left: 1003px;
        background-color: #fff;
        border: 1px solid #d9d9d9;
        box-sizing: border-box;
        width: 279px;
        height: 44px;
    }

    .groupChild8 {
        position: absolute;
        top: 81px;
        left: 1210px;
        background-color: #1ce785;
        width: 90px;
        height: 44px;
    }

    .signUp {
        position: absolute;
        top: 87px;
        left: 1227.5px;
        line-height: 32px;
        color: #000;
    }

    .email {
        position: absolute;
        top: 87px;
        left: 1020.75px;
        line-height: 32px;
        color: #999;
    }

    .groupChild9 {
        position: absolute;
        top: 145px;
        left: 1006px;
        border-radius: 4px;
        background-color: #fff;
        border: 1px solid #d9d9d9;
        box-sizing: border-box;
        width: 16px;
        height: 16px;
    }

    .groupChild10 {
        position: absolute;
        top: 343.5px;
        left: -0.5px;
        border-top: 1px solid #000;
        box-sizing: border-box;
        width: 1301px;
        height: 1px;
        opacity: 0.1;
    }

    .youtube1Icon {
        position: absolute;
        top: 244px;
        left: 1003px;
        width: 18px;
        height: 18px;
    }

    .linkedin1Icon {
        position: absolute;
        top: 244px;
        left: 1052.97px;
        width: 18px;
        height: 18px;
    }

    .facebook1Icon {
        position: absolute;
        top: 244px;
        left: 1102.93px;
        width: 18px;
        height: 18px;
    }

    .ins1Icon {
        position: absolute;
        top: 244px;
        left: 1152.9px;
        width: 18.1px;
        height: 18px;
    }

    .tiktok1Icon {
        position: absolute;
        top: 244px;
        left: 1203px;
        width: 18px;
        height: 18px;
    }

    .copyright2025 {
        position: absolute;
        top: 373px;
        left: 0px;
        font-size: 14px;
        line-height: 22px;
    }

    .designedByHoly {
        position: absolute;
        top: 373px;
        left: 1187px;
        font-size: 14px;
        line-height: 22px;
    }

</style>
