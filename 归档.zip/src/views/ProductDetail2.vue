<template>
    <div :class="$style.v10">
        <div :class="$style.maskGroup">
            <div :class="$style.div" />
            <div :class="$style.v10Div" />
        </div>
        <div :class="$style.v10Child" />
        <div :class="$style.v10Item" />
        <div :class="$style.v10Inner" />
        <div :class="$style.rectangleDiv" />
        <div :class="$style.v10V10Child" />
        <img :class="$style.rectangleIcon" alt="" />
        <div :class="$style.v10Child2" />
        <div :class="$style.v10Child3" />
        <b :class="$style.theGoldStandard">The gold standard for Rosin and Resin oils</b>
        <div :class="$style.ourPatentedUShape">Our patented U-shape ceramic features an extremely uniform pore
            structure, ideally suited for the molecular structure of Resin and Rosin. It is 30% thinner than ordinary
            ceramics, yet maintains the same strength. This means fewer terpene molecules are filtered out, preserving
            the rich, natural flavors.</div>
        <div :class="$style.poweredByUnicore">Powered by Unicore tech, UNIT PRO combines smoothness with purity,
            ensuring efficient THC and terpene extraction without burning, and guarantees an exceptional session every
            time.</div>
        <b :class="$style.b">30%</b>
        <div :class="$style.thinnerInStructure">Thinner in Structure</div>
        <b :class="$style.v10B">45%</b>
        <img :class="$style.icon" alt="" />
        <div :class="$style.flavorRetention">Flavor Retention</div>
        <b :class="$style.b2">35%</b>
        <img :class="$style.v10Icon" alt="" />
        <div :class="$style.inPoreUniformity">in Pore Uniformity</div>
        <div :class="$style.unicorePowered">UNICORE Powered</div>
        <b :class="$style.realizeYourUnique">Realize your unique design with CALEAF TECH.</b>
        <div :class="$style.designYourOwn">Design your own look</div>
        <i :class="$style.moreProducts">More Products</i>
        <div :class="$style.rectangleParent">
            <div :class="$style.groupChild" />
            <div :class="$style.unitUnicoreTechContainer">
                <b>UNIT<br /></b>
                <span :class="$style.unicoreTech">UNICORE™ tech & large display</span>
            </div>
            <img :class="$style.icon2" alt="" />
            <div :class="$style.groupItem" />
            <div :class="$style.viewMore">View More</div>
        </div>
        <div :class="$style.rectangleGroup">
            <div :class="$style.groupChild" />
            <div :class="$style.unitUnicoreTechContainer">
                <b>UNIT<br /></b>
                <span :class="$style.unicoreTech">UNICORE™ tech & large display</span>
            </div>
            <img :class="$style.icon2" alt="" />
            <div :class="$style.groupItem" />
            <div :class="$style.viewMore">View More</div>
        </div>
        <div :class="$style.rectangleContainer">
            <div :class="$style.groupChild" />
            <div :class="$style.unitUnicoreTechContainer">
                <b>UNIT<br /></b>
                <span :class="$style.unicoreTech">UNICORE™ tech & large display</span>
            </div>
            <img :class="$style.icon2" alt="" />
            <div :class="$style.groupItem" />
            <div :class="$style.viewMore">View More</div>
        </div>
        <div :class="$style.groupDiv">
            <div :class="$style.groupChild" />
            <div :class="$style.unitUnicoreTechContainer">
                <b>UNIT<br /></b>
                <span :class="$style.unicoreTech">UNICORE™ tech & large display</span>
            </div>
            <img :class="$style.icon2" alt="" />
            <div :class="$style.groupItem" />
            <div :class="$style.viewMore">View More</div>
        </div>
        <div :class="$style.ellipseDiv" />
        <img :class="$style.rightSmallIcon" alt="" />
        <div :class="$style.v10Child4" />
        <img :class="$style.v10RightSmallIcon" alt="" />
        <div :class="$style.v10Child5" />
        <div :class="$style.v10Child6" />
        <b :class="$style.eitherOnesA">Either one’s a winner</b>
        <div :class="$style.takeYourPick">Take your pick</div>
        <div :class="$style.rtdControl">RTD Control</div>
        <b :class="$style.consistentTempIdeal">Consistent Temp<br />Ideal for Rosin</b>
        <div :class="$style.theHeatingCoil">The heating coil is embedded within the ceramic core, this way, the oil is
            heated by the ceramic core and not by exposed hot wires, avoiding burnt flavors and preserving the terpenes
            and cannabinoids.</div>
        <div :class="$style.builtInWires">Built-in wires</div>
        <b :class="$style.noMoreDry">No more dry burning</b>
        <div :class="$style.withBigBranding">With big branding potential, it matches your vibe and makes the style
            uniquely yours.</div>
        <b :class="$style.itLooks">It looks — and stays — beautiful.</b>
        <div :class="$style.v10Child7" />
        <img :class="$style.v10Child8" alt="" />
        <div :class="$style.v10RectangleParent">
            <img :class="$style.groupChild6" alt="" />
            <img :class="$style.groupChild7" alt="" />
            <img :class="$style.groupChild8" alt="" />
            <img :class="$style.groupChild9" alt="" />
            <img :class="$style.groupChild10" alt="" />
            <img :class="$style.groupChild11" alt="" />
            <img :class="$style.groupChild12" alt="" />
            <img :class="$style.groupChild13" alt="" />
            <img :class="$style.groupChild14" alt="" />
            <img :class="$style.groupChild15" alt="" />
            <img :class="$style.groupChild16" alt="" />
            <img :class="$style.groupChild17" alt="" />
            <img :class="$style.groupChild18" alt="" />
        </div>
        <div :class="$style.universeSeriesIs">UNIVERSE Series is the ultimate portable solution for rosin enthusiasts.
            The little cutie disappears in your hand and fits flat in your pocket, making it the perfect companion for
            those on the go.</div>
        <b :class="$style.aPlamSizedRosin">A plam-sized<br />Rosin powerhouse</b>
        <div :class="$style.tinyButMighty">TINY BUT MIGHTY</div>
        <img :class="$style.icon6" alt="" />
        <b :class="$style.go">GO</b>
        <b :class="$style.pro">PRO</b>
        <img :class="$style.icon7" alt="" />
        <img :class="$style.icon8" alt="" />
        <div :class="$style.v10Child9" />
        <div :class="$style.v10Child10" />
        <img :class="$style.icon9" alt="" />
        <div :class="$style.v10Child11" />
        <b :class="$style.specifications">Specifications</b>
        <div :class="$style.v10Child12" />
        <div :class="$style.dimensionmm">Dimension(mm)</div>
        <b :class="$style.h390w140d">63.0H*39.0W*14.0D</b>
        <div :class="$style.v10Child13" />
        <div :class="$style.tankVolume">Tank Volume</div>
        <b :class="$style.ml2ml">1mL/ 2mL</b>
        <div :class="$style.v10Child14" />
        <div :class="$style.batteryCapability">Battery Capability</div>
        <b :class="$style.mah">280mAh</b>
        <div :class="$style.v10Child15" />
        <div :class="$style.resistance">Resistance</div>
        <b :class="$style.ohm">1.8ohm</b>
        <div :class="$style.v10Child16" />
        <div :class="$style.voltageSetting">Voltage Setting</div>
        <b :class="$style.v">2.2V</b>
        <div :class="$style.v10Child17" />
        <div :class="$style.housingMaterial">Housing Material</div>
        <b :class="$style.plastic">Plastic</b>
        <div :class="$style.v10Child18" />
        <div :class="$style.ceramicCore">Ceramic Core</div>
        <b :class="$style.unicore">UNICORE</b>
        <div :class="$style.v10Child19" />
        <div :class="$style.centralPost">Central Post</div>
        <b :class="$style.postFree">Post-free</b>
        <div :class="$style.v10Child20" />
        <div :class="$style.charging">Charging</div>
        <b :class="$style.typeC">Type-C</b>
        <div :class="$style.v10Child21" />
        <div :class="$style.optionsOfActivation">Options of Activation</div>
        <b :class="$style.inhaleActivated">Inhale Activated</b>
        <div :class="$style.v10Child22" />
        <div :class="$style.v10Dimensionmm">Dimension(mm)</div>
        <b :class="$style.h350w120d">58.5H*35.0W*12.0D</b>
        <div :class="$style.v10Child23" />
        <div :class="$style.v10TankVolume">Tank Volume</div>
        <b :class="$style.ml1ml">0.5mL/ 1mL</b>
        <div :class="$style.v10Child24" />
        <div :class="$style.v10BatteryCapability">Battery Capability</div>
        <b :class="$style.v10Mah">280mAh</b>
        <div :class="$style.v10Child25" />
        <div :class="$style.v10Resistance">Resistance</div>
        <b :class="$style.v10Ohm">1.8ohm</b>
        <div :class="$style.v10Child26" />
        <div :class="$style.v10VoltageSetting">Voltage Setting</div>
        <b :class="$style.v20v22v">1.8V-2.0V-2.2V</b>
        <div :class="$style.v10Child27" />
        <div :class="$style.v10HousingMaterial">Housing Material</div>
        <b :class="$style.v10Plastic">Plastic</b>
        <div :class="$style.v10Child28" />
        <div :class="$style.v10CeramicCore">Ceramic Core</div>
        <b :class="$style.v10Unicore">UNICORE</b>
        <div :class="$style.v10Child29" />
        <div :class="$style.v10CentralPost">Central Post</div>
        <b :class="$style.v10PostFree">Post-free</b>
        <div :class="$style.v10Child30" />
        <div :class="$style.v10Charging">Charging</div>
        <b :class="$style.v10TypeC">Type-C</b>
        <div :class="$style.v10Child31" />
        <div :class="$style.v10OptionsOfActivation">Options of Activation</div>
        <b :class="$style.buttonInhale">Button & Inhale Activated</b>
        <img :class="$style.icon10" alt="" />
        <b :class="$style.universe">UNIVERSE</b>
        <img :class="$style.icon11" alt="" />
        <b :class="$style.niversePro">NIVERSE Pro</b>
        <img :class="$style.v10Child32" alt="" />
        <img :class="$style.v10Child33" alt="" />
        <b :class="$style.pickYourOption">Pick Your Option</b>
        <b :class="$style.everyDetailMatters">Every Detail Matters</b>
        <div :class="$style.v10Child34" />
        <div :class="$style.v10Child35" />
        <div :class="$style.v10Child36" />
        <div :class="$style.v10Child37" />
        <div :class="$style.v10Child38" />
        <div :class="$style.crystalClearDesign">Crystal-clear Design</div>
        <div :class="$style.unibodyEnclosure">Unibody Enclosure</div>
        <div :class="$style.medicalGradeChamber">Medical-grade Chamber</div>
        <div :class="$style.v10Child39" />
        <div :class="$style.v10Universe">UNIVERSE</div>
        <div :class="$style.deepTrack30Container">
            <span :class="$style.deepTrack30">DEEP TRACK 3.0 |</span>
            <span :class="$style.span"> </span>
            <span :class="$style.v10Span"> 01</span>
        </div>
        <div :class="$style.v10Child40" />
        <div :class="$style.v10Child41" />
        <div :class="$style.v10Child42" />
        <div :class="$style.v10Child43" />
        <div :class="$style.v10Child44" />
        <div :class="$style.v10Child45" />
        <div :class="$style.v10Child46" />
        <div :class="$style.v10Child47" />
        <div :class="$style.intersect">
            <div :class="$style.intersectChild" />
            <div :class="$style.intersectItem" />
        </div>
        <img :class="$style.icon12" alt="" />
        <img :class="$style.icon13" alt="" />
        <div :class="$style.v10Child48" />
        <div :class="$style.v10Ml2ml">1mL/2mL</div>
        <div :class="$style.v10Child49" />
        <div :class="$style.v10Ml1ml">0.5mL / 1mL</div>
        <b :class="$style.universe2">UNIVERSE</b>
        <b :class="$style.universePro">UNIVERSE PRO</b>
        <div :class="$style.unicorePoweredThe">Unicore powered, the way to infinite.</div>
        <b :class="$style.relishTheGolden">Relish the golden hours with the UNIVERSE Series.</b>
        <b :class="$style.savorTheSweetnessContainer">
            <span>Savor the sweetness, dive into </span>
            <span :class="$style.v10Span">smoothness</span>
        </b>
        <div :class="$style.productsTechnologyCustomizeParent">
            <div :class="$style.productsTechnologyCustomize">Products Technology Customize US Local Service Why Caleaf
            </div>
            <img :class="$style.cc0971Icon" alt="" />
            <div :class="$style.groupChild19" />
            <div :class="$style.contact">Contact</div>
            <img :class="$style.icon14" alt="" />
        </div>
        <div :class="$style.productsParent">
            <b :class="$style.products">Products</b>
            <div :class="$style.forResinrosinPod">For Resin/Rosin<br />Pod System<br />Full Ceramic<br />D9
                Distillate<br />US STOCK<br />Dab Pen<br />510 Cartridge<br />D8 Distillate</div>
            <b :class="$style.technology">Technology</b>
            <div :class="$style.productSupportRepair">Product Support<br />Repair Service<br />After-Sales
                Policy<br />Care Service<br />Downloads</div>
            <b :class="$style.customize">Customize</b>
            <div :class="$style.v10ForResinrosinPod">For Resin/Rosin<br />Pod System<br />Full Ceramic<br />D9
                Distillate<br />US STOCK<br />Dab Pen<br />510 Cartridge<br />D8 Distillate</div>
            <b :class="$style.whyCaleaf">Why Caleaf</b>
            <div :class="$style.aboutCaleafPress">About Caleaf<br />Press<br />Blog<br />CSR<br />Awards<br />Join Us
            </div>
            <b :class="$style.subscribe">Subscribe</b>
            <div :class="$style.getTheLatest">Get the latest news from CALEAF TECH</div>
            <div :class="$style.iAgreeWithContainer">
                <span>I agree with the </span>
                <span :class="$style.privacyPolicy">Privacy Policy </span>
                <span>and l'dlike to receive the latest CALEAF TECH newsand deals by email.</span>
            </div>
            <div :class="$style.groupChild20" />
            <div :class="$style.groupChild21" />
            <div :class="$style.signUp">Sign Up</div>
            <div :class="$style.email">Email</div>
            <div :class="$style.groupChild22" />
            <div :class="$style.lineDiv" />
            <img :class="$style.youtube1Icon" alt="" />
            <img :class="$style.linkedin1Icon" alt="" />
            <img :class="$style.facebook1Icon" alt="" />
            <img :class="$style.ins1Icon" alt="" />
            <img :class="$style.tiktok1Icon" alt="" />
            <div :class="$style.copyright2025">Copyright © 2025 CALEAF TECH All rights reserved.</div>
            <div :class="$style.designedByHoly">Designed by HOLY</div>
        </div>
    </div>
</template>
<style
    module>
    .v10 {
        width: 100%;
        height: 13873px;
        position: relative;
        background-color: #fff;
        overflow: hidden;
        text-align: left;
        font-size: 18px;
        color: #fff;
        font-family: Roboto;
    }

    .maskGroup {
        position: absolute;
        top: 0px;
        left: 0px;
        width: 1920px;
        height: 980px;
    }

    .div {
        position: absolute;
        top: 100px;
        left: 0px;
        background-color: #000;
        width: 1920px;
        height: 880px;
    }

    .v10Div {
        position: absolute;
        top: 96.88px;
        left: -5px;
        background-color: #000;
        width: 2086px;
        height: 1043px;
    }

    .v10Child {
        position: absolute;
        top: 251px;
        left: calc(50% - 700px);
        filter: blur(300px);
        border-radius: 50%;
        background-color: #efd646;
        width: 1400px;
        height: 473px;
        opacity: 0.7;
    }

    .v10Item {
        position: absolute;
        top: 510px;
        left: 684px;
        filter: blur(200px);
        border-radius: 50%;
        background-color: #fff;
        width: 587px;
        height: 323px;
        opacity: 0.45;
    }

    .v10Inner {
        position: absolute;
        top: 980px;
        left: 0px;
        background-color: #111;
        width: 1920px;
        height: 880px;
    }

    .rectangleDiv {
        position: absolute;
        top: 1860px;
        left: 0px;
        background-color: #000;
        width: 1920px;
        height: 6039px;
    }

    .v10V10Child {
        position: absolute;
        top: 9362px;
        left: 0px;
        background-color: #000;
        width: 1920px;
        height: 4000px;
    }

    .rectangleIcon {
        position: absolute;
        top: 6409px;
        left: 345px;
        border-radius: 20px;
        width: 480px;
        height: 500px;
        object-fit: cover;
    }

    .v10Child2 {
        position: absolute;
        top: 7264px;
        left: 1095px;
        border-radius: 20px;
        background-color: #d9d9d9;
        width: 480px;
        height: 500px;
    }

    .v10Child3 {
        position: absolute;
        top: 7264px;
        right: 845px;
        border-radius: 20px;
        background-color: #d9d9d9;
        width: 730px;
        height: 500px;
    }

    .theGoldStandard {
        position: absolute;
        top: 4773.55px;
        left: calc(50% - 380px);
        font-size: 40px;
        text-align: center;
    }

    .ourPatentedUShape {
        position: absolute;
        top: 4839px;
        left: calc(50% - 600px);
        font-size: 20px;
        line-height: 30px;
        text-align: center;
        display: inline-block;
        width: 1200px;
        height: 77px;
    }

    .poweredByUnicore {
        position: absolute;
        top: 6192px;
        left: calc(50% - 615px);
        font-size: 20px;
        line-height: 30px;
        display: inline-block;
        width: 622.1px;
        height: 77px;
    }

    .b {
        position: absolute;
        top: 5011px;
        left: 619px;
        font-size: 40px;
        line-height: 30px;
        color: #1ce785;
    }

    .thinnerInStructure {
        position: absolute;
        top: 5051.72px;
        left: 571px;
        font-size: 20px;
        line-height: 30px;
    }

    .v10B {
        position: absolute;
        top: 5011px;
        left: 914.5px;
        font-size: 40px;
        line-height: 30px;
        color: #1ce785;
    }

    .icon {
        position: absolute;
        top: 5011px;
        left: 987.93px;
        width: 43.1px;
        height: 39.8px;
        object-fit: cover;
    }

    .flavorRetention {
        position: absolute;
        top: 5051.72px;
        left: 895.5px;
        font-size: 20px;
        line-height: 30px;
    }

    .b2 {
        position: absolute;
        top: 5011px;
        left: 1218px;
        font-size: 40px;
        line-height: 30px;
        color: #1ce785;
    }

    .v10Icon {
        position: absolute;
        top: 5011px;
        left: 1291.43px;
        width: 43.1px;
        height: 39.8px;
        object-fit: cover;
    }

    .inPoreUniformity {
        position: absolute;
        top: 5051.72px;
        left: 1191px;
        font-size: 20px;
        line-height: 30px;
    }

    .unicorePowered {
        position: absolute;
        top: 4731px;
        left: calc(50% - 83px);
        font-size: 20px;
        color: #1ce785;
    }

    .realizeYourUnique {
        position: absolute;
        top: 11796.55px;
        left: calc(50% - 424px);
        font-size: 40px;
        text-align: center;
    }

    .designYourOwn {
        position: absolute;
        top: 11754px;
        left: calc(50% - 96px);
        font-size: 20px;
        color: #1ce785;
    }

    .moreProducts {
        position: absolute;
        top: 12684px;
        left: calc(50% - 650px);
        font-size: 80px;
        line-height: 80px;
        font-weight: 800;
        color: #1ce785;
        text-align: center;
    }

    .rectangleParent {
        position: absolute;
        top: 12809px;
        left: 310px;
        width: 305px;
        height: 440px;
        font-size: 24px;
    }

    .groupChild {
        position: absolute;
        top: 0px;
        left: 0px;
        border-radius: 20px;
        background-color: #23242a;
        width: 305px;
        height: 440px;
    }

    .unitUnicoreTechContainer {
        position: absolute;
        top: 274px;
        left: 20px;
        line-height: 32px;
    }

    .unicoreTech {
        font-size: 16px;
        color: #f5f5f5;
    }

    .icon2 {
        position: absolute;
        top: 63px;
        left: 60px;
        width: 185px;
        height: 165px;
        object-fit: cover;
    }

    .groupItem {
        position: absolute;
        top: 358px;
        left: 20px;
        border-radius: 50px;
        background-color: #1ce785;
        width: 130px;
        height: 40px;
    }

    .viewMore {
        position: absolute;
        top: 369px;
        left: 47px;
        font-size: 16px;
        color: #000;
    }

    .rectangleGroup {
        position: absolute;
        top: 12809px;
        left: 642px;
        width: 305px;
        height: 440px;
        font-size: 24px;
    }

    .rectangleContainer {
        position: absolute;
        top: 12809px;
        left: 974px;
        width: 305px;
        height: 440px;
        font-size: 24px;
    }

    .groupDiv {
        position: absolute;
        top: 12809px;
        left: 1306px;
        width: 305px;
        height: 440px;
        font-size: 24px;
    }

    .ellipseDiv {
        position: absolute;
        top: 13004px;
        left: 1550px;
        border-radius: 50%;
        background-color: #1ce785;
        width: 50px;
        height: 50px;
    }

    .rightSmallIcon {
        position: absolute;
        top: 13017px;
        left: 1563px;
        width: 24px;
        height: 24px;
    }

    .v10Child4 {
        position: absolute;
        top: 13004px;
        left: 320px;
        border-radius: 50%;
        background-color: #fff;
        width: 50px;
        height: 50px;
    }

    .v10RightSmallIcon {
        position: absolute;
        top: 13017px;
        left: 333px;
        width: 24px;
        height: 24px;
        object-fit: contain;
        opacity: 0.4;
    }

    .v10Child5 {
        position: absolute;
        top: 4171.05px;
        right: 970px;
        border-radius: 20px;
        background-color: #d9d9d9;
        width: 605px;
        height: 440px;
    }

    .v10Child6 {
        position: absolute;
        top: 4171.05px;
        right: 345px;
        border-radius: 20px;
        background-color: #d9d9d9;
        width: 605px;
        height: 440px;
    }

    .eitherOnesA {
        position: absolute;
        top: 4070.55px;
        left: calc(50% - 184px);
        font-size: 40px;
    }

    .takeYourPick {
        position: absolute;
        top: 4028px;
        left: calc(50% - 64px);
        font-size: 20px;
        color: #1ce785;
    }

    .rtdControl {
        position: absolute;
        top: 6001px;
        left: calc(50% - 615px);
        font-size: 20px;
        color: #1ce785;
    }

    .consistentTempIdeal {
        position: absolute;
        top: 6043px;
        left: calc(50% - 615px);
        font-size: 40px;
    }

    .theHeatingCoil {
        position: absolute;
        top: 7098px;
        left: calc(50% - 7.07px);
        font-size: 20px;
        line-height: 30px;
        display: inline-block;
        width: 622.1px;
        height: 77px;
    }

    .builtInWires {
        position: absolute;
        top: 7055px;
        left: calc(50% - 615px);
        font-size: 20px;
        color: #1ce785;
    }

    .noMoreDry {
        position: absolute;
        top: 7097px;
        left: calc(50% - 615px);
        font-size: 40px;
    }

    .withBigBranding {
        position: absolute;
        top: 10430px;
        left: calc(50% - 615px);
        font-size: 20px;
        line-height: 30px;
        display: inline-block;
        width: 627px;
        height: 77px;
    }

    .itLooks {
        position: absolute;
        top: 10339px;
        left: calc(50% - 615px);
        font-size: 40px;
    }

    .v10Child7 {
        position: absolute;
        top: 10272px;
        right: 345px;
        border-radius: 20px;
        background-color: #d9d9d9;
        width: 560px;
        height: 340px;
    }

    .v10Child8 {
        position: absolute;
        top: 6409px;
        left: calc(50% - 115px);
        border-radius: 20px;
        width: 730px;
        height: 500px;
        object-fit: cover;
    }

    .v10RectangleParent {
        position: absolute;
        top: 1276px;
        left: 345px;
        width: 1230px;
        height: 670px;
    }

    .groupChild6 {
        position: absolute;
        top: 0px;
        left: 0px;
        border-radius: 10px;
        width: 400px;
        height: 180px;
        object-fit: cover;
    }

    .groupChild7 {
        position: absolute;
        top: 196.67px;
        left: 0px;
        border-radius: 10px;
        width: 400px;
        height: 160px;
        object-fit: cover;
    }

    .groupChild8 {
        position: absolute;
        top: 373.33px;
        left: 0px;
        border-radius: 10px;
        width: 400px;
        height: 140px;
        object-fit: cover;
    }

    .groupChild9 {
        position: absolute;
        top: 530px;
        left: 0px;
        border-radius: 10px;
        width: 240px;
        height: 140px;
        object-fit: cover;
    }

    .groupChild10 {
        position: absolute;
        top: 0px;
        left: 415px;
        border-radius: 10px;
        width: 400px;
        height: 513.3px;
        object-fit: cover;
    }

    .groupChild11 {
        position: absolute;
        top: 530px;
        left: 440.5px;
        border-radius: 10px;
        width: 240px;
        height: 140px;
        object-fit: cover;
    }

    .groupChild12 {
        position: absolute;
        top: 530px;
        left: 695.5px;
        border-radius: 10px;
        width: 240px;
        height: 140px;
        object-fit: cover;
    }

    .groupChild13 {
        position: absolute;
        top: 0px;
        left: 830px;
        border-radius: 10px;
        width: 400px;
        height: 180px;
        object-fit: cover;
    }

    .groupChild14 {
        position: absolute;
        top: 196.67px;
        left: 830px;
        border-radius: 10px;
        width: 400px;
        height: 160px;
        object-fit: cover;
    }

    .groupChild15 {
        position: absolute;
        top: 373.33px;
        left: 830px;
        border-radius: 10px;
        width: 170px;
        height: 140px;
        object-fit: cover;
    }

    .groupChild16 {
        position: absolute;
        top: 530px;
        left: 255.5px;
        border-radius: 10px;
        width: 170px;
        height: 140px;
        object-fit: cover;
    }

    .groupChild17 {
        position: absolute;
        top: 373.33px;
        left: 1015px;
        border-radius: 10px;
        width: 215px;
        height: 140px;
        object-fit: cover;
    }

    .groupChild18 {
        position: absolute;
        top: 530px;
        left: 950px;
        border-radius: 10px;
        width: 280px;
        height: 140px;
        object-fit: cover;
    }

    .universeSeriesIs {
        position: absolute;
        top: 3159px;
        left: calc(50% - 600px);
        font-size: 20px;
        line-height: 30px;
        text-align: center;
        display: inline-block;
        width: 1200px;
        height: 77px;
    }

    .aPlamSizedRosin {
        position: absolute;
        top: 3047.55px;
        left: calc(50% - 166px);
        font-size: 40px;
        text-align: center;
    }

    .tinyButMighty {
        position: absolute;
        top: 3005px;
        left: calc(50% - 87px);
        font-size: 20px;
        color: #1ce785;
    }

    .icon6 {
        position: absolute;
        top: 2163px;
        left: calc(50% - 700px);
        width: 1400px;
        height: 656px;
        object-fit: cover;
    }

    .go {
        position: absolute;
        top: 2369px;
        left: calc(50% - 391px);
        font-size: 200px;
        line-height: 80px;
        background: linear-gradient(180deg, #1ce785, #a8ffd5 50%, #1ce785);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
    }

    .pro {
        position: absolute;
        top: 2369px;
        left: calc(50% + 111px);
        font-size: 200px;
        line-height: 80px;
        background: linear-gradient(180deg, #1ce785, #a8ffd5 50%, #1ce785);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
    }

    .icon7 {
        position: absolute;
        top: 3236px;
        left: calc(50% - 700px);
        width: 1400px;
        height: 633px;
        object-fit: cover;
    }

    .icon8 {
        position: absolute;
        top: 5228px;
        left: calc(50% - 184px);
        width: 369px;
        height: 483px;
        object-fit: cover;
    }

    .v10Child9 {
        position: absolute;
        top: 5354px;
        left: 345px;
        border-radius: 20px;
        background-color: #d9d9d9;
        width: 330px;
        height: 460px;
    }

    .v10Child10 {
        position: absolute;
        top: 5177px;
        left: 1245px;
        border-radius: 20px;
        background-color: #d9d9d9;
        width: 330px;
        height: 460px;
    }

    .icon9 {
        position: absolute;
        top: 5856px;
        left: 1031px;
        width: 454px;
        height: 553px;
        object-fit: cover;
    }

    .v10Child11 {
        position: absolute;
        top: 6231px;
        left: 999px;
        background: linear-gradient(180deg, rgba(0, 0, 0, 0), #000);
        width: 521px;
        height: 178px;
    }

    .specifications {
        position: absolute;
        top: 8035px;
        left: 345px;
        font-size: 40px;
        color: #000;
    }

    .v10Child12 {
        position: absolute;
        top: 8137px;
        left: 345px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .dimensionmm {
        position: absolute;
        top: 8154.38px;
        left: 399px;
        font-size: 16px;
        color: #666;
    }

    .h390w140d {
        position: absolute;
        top: 8183.13px;
        left: 374px;
        color: #111;
    }

    .v10Child13 {
        position: absolute;
        top: 8137px;
        left: 585px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .tankVolume {
        position: absolute;
        top: 8154.38px;
        left: 649px;
        font-size: 16px;
        color: #666;
    }

    .ml2ml {
        position: absolute;
        top: 8183.13px;
        left: 653px;
        color: #111;
    }

    .v10Child14 {
        position: absolute;
        top: 8232px;
        left: 345px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .batteryCapability {
        position: absolute;
        top: 8249.38px;
        left: 392px;
        font-size: 16px;
        color: #666;
    }

    .mah {
        position: absolute;
        top: 8278.13px;
        left: 420px;
        color: #111;
    }

    .v10Child15 {
        position: absolute;
        top: 8232px;
        left: 585px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .resistance {
        position: absolute;
        top: 8249.38px;
        left: 655px;
        font-size: 16px;
        color: #666;
    }

    .ohm {
        position: absolute;
        top: 8278.13px;
        left: 663px;
        color: #111;
    }

    .v10Child16 {
        position: absolute;
        top: 8327px;
        left: 345px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .voltageSetting {
        position: absolute;
        top: 8344.38px;
        left: 401px;
        font-size: 16px;
        color: #666;
    }

    .v {
        position: absolute;
        top: 8373.13px;
        left: 436px;
        color: #111;
    }

    .v10Child17 {
        position: absolute;
        top: 8327px;
        left: 585px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .housingMaterial {
        position: absolute;
        top: 8344.38px;
        left: 635px;
        font-size: 16px;
        color: #666;
    }

    .plastic {
        position: absolute;
        top: 8373.13px;
        left: 666px;
        color: #111;
    }

    .v10Child18 {
        position: absolute;
        top: 8422px;
        left: 345px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .ceramicCore {
        position: absolute;
        top: 8439.38px;
        left: 406px;
        font-size: 16px;
        color: #666;
    }

    .unicore {
        position: absolute;
        top: 8468.13px;
        left: 413px;
        color: #111;
    }

    .v10Child19 {
        position: absolute;
        top: 8422px;
        left: 585px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .centralPost {
        position: absolute;
        top: 8439.38px;
        left: 651px;
        font-size: 16px;
        color: #666;
    }

    .postFree {
        position: absolute;
        top: 8468.13px;
        left: 656px;
        color: #111;
    }

    .v10Child20 {
        position: absolute;
        top: 8517px;
        left: 345px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .charging {
        position: absolute;
        top: 8534.38px;
        left: 423px;
        font-size: 16px;
        color: #666;
    }

    .typeC {
        position: absolute;
        top: 8563.13px;
        left: 425px;
        color: #111;
    }

    .v10Child21 {
        position: absolute;
        top: 8517px;
        left: 585px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .optionsOfActivation {
        position: absolute;
        top: 8534.38px;
        left: 622px;
        font-size: 16px;
        color: #666;
    }

    .inhaleActivated {
        position: absolute;
        top: 8563.13px;
        left: 626px;
        color: #111;
    }

    .v10Child22 {
        position: absolute;
        top: 8724px;
        left: 1115px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .v10Dimensionmm {
        position: absolute;
        top: 8741.38px;
        left: 1169px;
        font-size: 16px;
        color: #666;
    }

    .h350w120d {
        position: absolute;
        top: 8770.13px;
        left: 1144px;
        color: #111;
    }

    .v10Child23 {
        position: absolute;
        top: 8724px;
        left: 1355px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .v10TankVolume {
        position: absolute;
        top: 8741.38px;
        left: 1419px;
        font-size: 16px;
        color: #666;
    }

    .ml1ml {
        position: absolute;
        top: 8770.13px;
        left: 1415px;
        color: #111;
    }

    .v10Child24 {
        position: absolute;
        top: 8819px;
        left: 1115px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .v10BatteryCapability {
        position: absolute;
        top: 8836.38px;
        left: 1162px;
        font-size: 16px;
        color: #666;
    }

    .v10Mah {
        position: absolute;
        top: 8865.13px;
        left: 1190px;
        color: #111;
    }

    .v10Child25 {
        position: absolute;
        top: 8819px;
        left: 1355px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .v10Resistance {
        position: absolute;
        top: 8836.38px;
        left: 1425px;
        font-size: 16px;
        color: #666;
    }

    .v10Ohm {
        position: absolute;
        top: 8865.13px;
        left: 1433px;
        color: #111;
    }

    .v10Child26 {
        position: absolute;
        top: 8914px;
        left: 1115px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .v10VoltageSetting {
        position: absolute;
        top: 8931.38px;
        left: 1171px;
        font-size: 16px;
        color: #666;
    }

    .v20v22v {
        position: absolute;
        top: 8960.13px;
        left: 1164px;
        color: #111;
    }

    .v10Child27 {
        position: absolute;
        top: 8914px;
        left: 1355px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .v10HousingMaterial {
        position: absolute;
        top: 8931.38px;
        left: 1405px;
        font-size: 16px;
        color: #666;
    }

    .v10Plastic {
        position: absolute;
        top: 8960.13px;
        left: 1436px;
        color: #111;
    }

    .v10Child28 {
        position: absolute;
        top: 9009px;
        left: 1115px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .v10CeramicCore {
        position: absolute;
        top: 9026.38px;
        left: 1176px;
        font-size: 16px;
        color: #666;
    }

    .v10Unicore {
        position: absolute;
        top: 9055.13px;
        left: 1183px;
        color: #111;
    }

    .v10Child29 {
        position: absolute;
        top: 9009px;
        left: 1355px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .v10CentralPost {
        position: absolute;
        top: 9026.38px;
        left: 1421px;
        font-size: 16px;
        color: #666;
    }

    .v10PostFree {
        position: absolute;
        top: 9055.13px;
        left: 1426px;
        color: #111;
    }

    .v10Child30 {
        position: absolute;
        top: 9104px;
        left: 1115px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .v10Charging {
        position: absolute;
        top: 9121.38px;
        left: 1193px;
        font-size: 16px;
        color: #666;
    }

    .v10TypeC {
        position: absolute;
        top: 9150.13px;
        left: 1195px;
        color: #111;
    }

    .v10Child31 {
        position: absolute;
        top: 9104px;
        left: 1355px;
        border-radius: 10px;
        background-color: #d9d9d9;
        width: 220px;
        height: 80px;
        opacity: 0.2;
    }

    .v10OptionsOfActivation {
        position: absolute;
        top: 9121.38px;
        left: 1392px;
        font-size: 16px;
        color: #666;
    }

    .buttonInhale {
        position: absolute;
        top: 9150.13px;
        left: 1356px;
        color: #111;
    }

    .icon10 {
        position: absolute;
        top: 8137px;
        left: 1045px;
        width: 334px;
        height: 412px;
        object-fit: cover;
    }

    .universe {
        position: absolute;
        top: 8577px;
        left: 1156px;
        font-size: 22px;
        color: #000;
    }

    .icon11 {
        position: absolute;
        top: 8698px;
        left: 502px;
        width: 331px;
        height: 423px;
        object-fit: cover;
    }

    .niversePro {
        position: absolute;
        top: 9152px;
        left: 591px;
        font-size: 22px;
        color: #000;
    }

    .v10Child32 {
        position: absolute;
        top: 9892px;
        left: 349px;
        width: 257px;
        height: 114px;
    }

    .v10Child33 {
        position: absolute;
        top: 9628px;
        left: 1314px;
        width: 257px;
        height: 114px;
        object-fit: contain;
    }

    .pickYourOption {
        position: absolute;
        top: 9777px;
        left: calc(50% - 451px);
        font-size: 120px;
        line-height: 80px;
        background: linear-gradient(180deg, #1ce785, #c9ffe5 50%, #1ce785);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
    }

    .everyDetailMatters {
        position: absolute;
        top: 10903px;
        left: calc(50% - 181.5px);
        font-size: 40px;
        background: linear-gradient(90deg, #1ce785, #80ffc1 50%, #1ce785);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
    }

    .v10Child34 {
        position: absolute;
        top: 11008px;
        left: calc(50% - 400px);
        border-radius: 20px;
        background-color: #d9d9d9;
        width: 800px;
        height: 500px;
    }

    .v10Child35 {
        position: absolute;
        top: 11548px;
        left: calc(50% - 400px);
        border-radius: 50px;
        background-color: #fff;
        width: 800px;
        height: 50px;
        opacity: 0.12;
    }

    .v10Child36 {
        position: absolute;
        top: 11548px;
        left: calc(50% - 400px);
        border-radius: 50px;
        background-color: #1ce785;
        width: 260px;
        height: 50px;
    }

    .v10Child37 {
        position: absolute;
        top: 11008px;
        left: calc(50% - 1220px);
        border-radius: 20px;
        background-color: #f5f5f5;
        width: 800px;
        height: 500px;
    }

    .v10Child38 {
        position: absolute;
        top: 11008px;
        left: calc(50% + 420px);
        border-radius: 20px;
        background-color: #f5f5f5;
        width: 800px;
        height: 500px;
    }

    .crystalClearDesign {
        position: absolute;
        top: 11562.5px;
        left: 609px;
        color: #111;
    }

    .unibodyEnclosure {
        position: absolute;
        top: 11562.5px;
        left: 867.5px;
        color: #d9d9d9;
    }

    .medicalGradeChamber {
        position: absolute;
        top: 11562.5px;
        left: 1118px;
        color: #d9d9d9;
    }

    .v10Child39 {
        position: absolute;
        top: 10275px;
        left: 345px;
        border-radius: 50px;
        background-color: #1ce785;
        width: 140px;
        height: 40px;
    }

    .v10Universe {
        position: absolute;
        top: 10285px;
        left: 369px;
        color: #000;
    }

    .deepTrack30Container {
        position: absolute;
        top: 10685px;
        left: calc(50% - 79px);
        font-size: 14px;
        color: rgba(255, 255, 255, 0.8);
    }

    .deepTrack30 {
        white-space: pre-wrap;
    }

    .span {
        color: #fff;
        white-space: pre-wrap;
    }

    .v10Span {
        color: #1ce785;
    }

    .v10Child40 {
        position: absolute;
        top: 11897px;
        left: 261px;
        border-radius: 20px;
        background-color: #d9d9d9;
        width: 480px;
        height: 300px;
    }

    .v10Child41 {
        position: absolute;
        top: 11897px;
        left: 771px;
        border-radius: 20px;
        background-color: #d9d9d9;
        width: 480px;
        height: 300px;
    }

    .v10Child42 {
        position: absolute;
        top: 11897px;
        left: 1281px;
        border-radius: 20px;
        background-color: #d9d9d9;
        width: 480px;
        height: 300px;
    }

    .v10Child43 {
        position: absolute;
        top: 12217px;
        left: 160px;
        border-radius: 20px;
        background-color: #d9d9d9;
        width: 480px;
        height: 300px;
    }

    .v10Child44 {
        position: absolute;
        top: 12217px;
        left: 670px;
        border-radius: 20px;
        background-color: #d9d9d9;
        width: 480px;
        height: 300px;
    }

    .v10Child45 {
        position: absolute;
        top: 12217px;
        left: 1180px;
        border-radius: 20px;
        background-color: #d9d9d9;
        width: 480px;
        height: 300px;
    }

    .v10Child46 {
        position: absolute;
        top: 12208px;
        left: 160px;
        background: linear-gradient(-90deg, rgba(0, 0, 0, 0), #000);
        width: 185px;
        height: 318px;
    }

    .v10Child47 {
        position: absolute;
        top: 11879px;
        left: 1761px;
        background: linear-gradient(-90deg, rgba(0, 0, 0, 0), #000);
        width: 185px;
        height: 318px;
        transform: rotate(180deg);
        transform-origin: 0 0;
    }

    .intersect {
        position: relative;
        filter: blur(200px);
        background-color: #fbeb00;
        width: 727.9px;
        height: 55px;
    }

    .intersectChild {
        position: absolute;
        top: 686px;
        left: 0px;
        background-color: #050401;
        width: 1920px;
        height: 294px;
    }

    .intersectItem {
        position: absolute;
        top: 522px;
        left: 536px;
        filter: blur(200px);
        border-radius: 50%;
        background-color: #fbeb00;
        width: 839px;
        height: 219px;
        opacity: 0.5;
    }

    .icon12 {
        position: absolute;
        top: 238px;
        left: 557px;
        width: 354px;
        height: 459px;
        object-fit: cover;
    }

    .icon13 {
        position: absolute;
        top: 157px;
        left: 1088px;
        width: 328px;
        height: 473px;
        object-fit: cover;
    }

    .v10Child48 {
        position: absolute;
        top: 765px;
        left: 643px;
        border-radius: 50px;
        background-color: #1ce785;
        width: 120px;
        height: 40px;
    }

    .v10Ml2ml {
        position: absolute;
        top: 774.5px;
        left: 665px;
        color: #222;
    }

    .v10Child49 {
        position: absolute;
        top: 684px;
        left: 1172px;
        border-radius: 50px;
        background-color: #1ce785;
        width: 120px;
        height: 40px;
    }

    .v10Ml1ml {
        position: absolute;
        top: 693.5px;
        left: 1182px;
        color: #222;
    }

    .universe2 {
        position: absolute;
        top: 712px;
        left: 366px;
        font-size: 30px;
        display: inline-block;
        text-align: center;
        width: 678px;
    }

    .universePro {
        position: absolute;
        top: 631px;
        left: 893px;
        font-size: 30px;
        display: inline-block;
        text-align: center;
        width: 678px;
    }

    .unicorePoweredThe {
        position: absolute;
        top: 847px;
        left: calc(50% - 192px);
        font-size: 24px;
        color: #d9d9d9;
        text-align: center;
    }

    .relishTheGolden {
        position: absolute;
        top: 1103px;
        left: calc(50% - 492px);
        font-size: 40px;
        font-family: Inter;
        text-align: center;
    }

    .savorTheSweetnessContainer {
        position: absolute;
        top: 1165px;
        left: calc(50% - 435px);
        font-size: 40px;
        text-transform: capitalize;
        font-family: Inter;
        text-align: center;
    }

    .productsTechnologyCustomizeParent {
        position: absolute;
        top: 30px;
        left: 310px;
        width: 1300px;
        height: 40px;
        font-size: 16px;
        color: #555;
    }

    .productsTechnologyCustomize {
        position: absolute;
        top: 8.5px;
        left: 247px;
        white-space: pre-wrap;
    }

    .cc0971Icon {
        position: absolute;
        top: 4px;
        left: 0px;
        width: 187.2px;
        height: 30px;
        object-fit: cover;
    }

    .groupChild19 {
        position: absolute;
        top: 0px;
        left: 1106px;
        border-radius: 50px;
        background-color: #1ce785;
        width: 140px;
        height: 40px;
    }

    .contact {
        position: absolute;
        top: 8.5px;
        left: 1143.5px;
        font-size: 18px;
        color: #222;
    }

    .icon14 {
        position: absolute;
        top: 9px;
        left: 1278px;
        width: 22px;
        height: 22px;
    }

    .productsParent {
        position: absolute;
        top: 13453px;
        left: 310px;
        width: 1301px;
        height: 395px;
        font-size: 16px;
        color: #555;
    }

    .products {
        position: absolute;
        top: 0px;
        left: 0px;
        font-size: 18px;
        display: inline-block;
        color: #000;
        width: 131px;
    }

    .forResinrosinPod {
        position: absolute;
        top: 32px;
        left: 0px;
        line-height: 32px;
        display: inline-block;
        width: 131px;
    }

    .technology {
        position: absolute;
        top: 0px;
        left: 237px;
        font-size: 18px;
        display: inline-block;
        color: #000;
        width: 131px;
    }

    .productSupportRepair {
        position: absolute;
        top: 32px;
        left: 237px;
        line-height: 32px;
        display: inline-block;
        width: 153px;
    }

    .customize {
        position: absolute;
        top: 0px;
        left: 496px;
        font-size: 18px;
        display: inline-block;
        color: #000;
        width: 131px;
    }

    .v10ForResinrosinPod {
        position: absolute;
        top: 32px;
        left: 496px;
        line-height: 32px;
        display: inline-block;
        width: 113px;
    }

    .whyCaleaf {
        position: absolute;
        top: 0px;
        left: 716px;
        font-size: 18px;
        display: inline-block;
        color: #000;
        width: 131px;
    }

    .aboutCaleafPress {
        position: absolute;
        top: 32px;
        left: 715px;
        line-height: 32px;
        display: inline-block;
        width: 102px;
    }

    .subscribe {
        position: absolute;
        top: 0px;
        left: 1003px;
        font-size: 18px;
        display: inline-block;
        color: #000;
        width: 131px;
    }

    .getTheLatest {
        position: absolute;
        top: 32px;
        left: 1003px;
        line-height: 32px;
        display: inline-block;
        width: 297px;
    }

    .iAgreeWithContainer {
        position: absolute;
        top: 142px;
        left: 1032px;
        font-size: 14px;
        line-height: 22px;
        display: inline-block;
        width: 268px;
    }

    .privacyPolicy {
        color: #000;
    }

    .groupChild20 {
        position: absolute;
        top: 81px;
        left: 1003px;
        background-color: #fff;
        border: 1px solid #d9d9d9;
        box-sizing: border-box;
        width: 279px;
        height: 44px;
    }

    .groupChild21 {
        position: absolute;
        top: 81px;
        left: 1210px;
        background-color: #1ce785;
        width: 90px;
        height: 44px;
    }

    .signUp {
        position: absolute;
        top: 87px;
        left: 1227.5px;
        line-height: 32px;
        color: #000;
    }

    .email {
        position: absolute;
        top: 87px;
        left: 1020.75px;
        line-height: 32px;
        color: #999;
    }

    .groupChild22 {
        position: absolute;
        top: 145px;
        left: 1006px;
        border-radius: 4px;
        background-color: #fff;
        border: 1px solid #d9d9d9;
        box-sizing: border-box;
        width: 16px;
        height: 16px;
    }

    .lineDiv {
        position: absolute;
        top: 343.5px;
        left: -0.5px;
        border-top: 1px solid #000;
        box-sizing: border-box;
        width: 1301px;
        height: 1px;
        opacity: 0.1;
    }

    .youtube1Icon {
        position: absolute;
        top: 244px;
        left: 1003px;
        width: 18px;
        height: 18px;
    }

    .linkedin1Icon {
        position: absolute;
        top: 244px;
        left: 1052.97px;
        width: 18px;
        height: 18px;
    }

    .facebook1Icon {
        position: absolute;
        top: 244px;
        left: 1102.93px;
        width: 18px;
        height: 18px;
    }

    .ins1Icon {
        position: absolute;
        top: 244px;
        left: 1152.9px;
        width: 18.1px;
        height: 18px;
    }

    .tiktok1Icon {
        position: absolute;
        top: 244px;
        left: 1203px;
        width: 18px;
        height: 18px;
    }

    .copyright2025 {
        position: absolute;
        top: 373px;
        left: 0px;
        font-size: 14px;
        line-height: 22px;
    }

    .designedByHoly {
        position: absolute;
        top: 373px;
        left: 1187px;
        font-size: 14px;
        line-height: 22px;
    }

</style>
