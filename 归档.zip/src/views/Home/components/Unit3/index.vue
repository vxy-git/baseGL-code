<script setup>

</script>

<template>
<div>
  <div class="w-[1300px] mx-auto mt-[70px]">
    <div class="relative">
      <div class="absolute size-full left-0 top-0 z-10">
        <div class="w-[374px] pt-[128.5px] ml-[118px]">
          <div class="tag text-center">New</div>
          <div class="title mt-[11px]">
            UNICORE™<br/>
            ceramic heating technology
          </div>
          <div class="subTitle mt-[15px]">
            Patented U-shape ceramic design<br/>
            The golden standard for ROSIN
          </div>
          <div class="btn mx-auto mt-[38px] cursor-pointer">
            Learn more
          </div>
        </div>
      </div>
      <img src="@/assets/img/icon8.png" alt="">
    </div>
  </div>
</div>
</template>

<style scoped lang="scss">
.tag{
  color: #1CE785;
  font-family: Roboto;
  font-size: 20px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
}
.title{
  color: #000;
  text-align: center;
  font-family: Roboto;
  font-size: 30px;
  font-style: normal;
  font-weight: 700;
  line-height: 35px;
}
.subTitle{
  color: #555;
  text-align: center;
  font-family: Roboto;
  font-size: 20px;
  font-style: normal;
  font-weight: 400;
  line-height: 23px;
}
.btn{
  width: 160px;
  height: 40px;
  flex-shrink: 0;
  border-radius: 50px;
  background: #1CE785;
  color: #222;
  font-family: Roboto;
  font-size: 18px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>