<script setup>

</script>

<template>
<div class="mt-[87px]">
  <div class="title text-center">
    Realize your unique design with CALEAF TECH
  </div>
  <img class="mt-[52px] w-full h-[763px]" src="@/assets/img/icon9.png" alt="">
</div>
</template>

<style scoped lang="scss">
.title{
  color: #000;
  font-family: Roboto;
  font-size: 40px;
  font-style: normal;
  font-weight: 700;
  line-height: 47px;
}
</style>