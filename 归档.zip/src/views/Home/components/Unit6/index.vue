<script setup>

</script>

<template>
  <div>
    <div class="w-[1300px] mt-[83px] mx-auto">
      <div>
        <div class="relative">
          <div class="size-full absolute z-10 top-0 left-0 pt-[122px]">
            <div class="titleText">Beyond Limits</div>
            <div class="label">
              At Caleaf Tech, we don't settle for what others consider "good enough." We push the boundaries of what's possible, constantly seeking technological breakthroughs to deliver the absolute best. When others say "That's as far as we can go," we say "This is just the beginning." We're committed to making every puff not just delicious, but unforgettable, and every customer experience not just satisfactory, but exceptional.
            </div>
            <img class="size-[50px] mx-auto mt-[20.25px] cursor-pointer" src="@/assets/img/icon10.png" alt="">
          </div>
          <img class="h-[560px] w-full object-cover" src="@/assets/img/t2.png" alt="">
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
.titleText {
  color: #FFF;
  text-align: center;
  font-family: Roboto;
  font-size: 50px;
  font-style: normal;
  font-weight: 700;
  line-height: 59px;

}
.label{
  margin: 27.25px auto 0;
  width: 1000px;
  color: #FFF;
  text-align: center;
  font-family: Roboto;
  font-size: 22px;
  font-style: normal;
  font-weight: 400;
  line-height: 30px; /* 136.364% */
}
</style>